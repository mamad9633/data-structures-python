from setuptools import setup, find_packages

setup(
    name="data-structures-package",
    version="0.1.0",
    packages=find_packages(),
    description="A collection of data structure implementations",
    author="Elhadji Mamadou",
    author_email="your.email@example.com",
    python_requires=">=3.6",
)